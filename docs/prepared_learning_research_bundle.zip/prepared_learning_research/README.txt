THE COST OF PREPARING A NETWORK TO LEARN
Research bundle, 31 October 2026

Status: complete proofs within a specified model; historical originality is
uncertain. Read research_note.pdf for assumptions, proofs, the novelty
assessment, and limitations. Computational experiments are not proofs.

Contents
  research_note.pdf            Complete research note
  research_note.tex            Main LaTeX document and bibliography
  geometry_section.tex        Exact norm, width, and parameter-count results
  phase_section.tex           Statistical transition and general threshold
  verification_section.tex    Executed checks and finite-step counterexample
  verify_plasticity.py         First numerical implementation (NumPy)
  results_plasticity.json      Recorded output
  audit_geometry.py           Independent complex-step and geometry audit
  audit_geometry_results.json Recorded independent output
  phase_transition.py         Statistical Monte Carlo and quadratic program
  results_phase.json          Recorded output, including failed diagnostics
  plot_phase.py               Recreates the analytic phase diagram
  figures/phase_diagram.pdf   Vector figure
  figures/phase_diagram_note.pdf  Portrait figure used in the note
  figures/phase_diagram.png   Raster figure
  literature_plasticity.txt   Primary-source search notes

Dependencies
  Python 3, NumPy, SciPy, Matplotlib.
  A LaTeX installation with pdflatex for rebuilding the manuscript.

Run from this directory:
  python3 verify_plasticity.py --output results_plasticity.json
  python3 audit_geometry.py
  python3 phase_transition.py --output results_phase_rerun.json
  python3 plot_phase.py
  pdflatex -interaction=nonstopmode -halt-on-error research_note.tex
  pdflatex -interaction=nonstopmode -halt-on-error research_note.tex

The optional full-matrix solver diagnostic in phase_transition.py uses a
nonsmooth eigenvalue constraint and may fail convergence. It is not used as
a proof or certificate. The default diagonal quadratic program has linear
constraints and was checked independently of the displayed closed form.
The recorded JSON preserves the earlier full-matrix failures honestly.

All formulas assume independent Euclidean parameter coordinates in a
fully connected scalar-output deep linear network with no biases or fixed
normalization factors. The statistical theorem concerns one linear update
with a fixed unit learning rate and isotropic Gaussian inputs.
