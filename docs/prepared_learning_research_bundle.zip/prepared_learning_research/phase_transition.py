"""Numerical checks of the null-network resource / plasticity phase theorem.

This script verifies formulas; finite calculations are not a general proof.
"""
import json
import argparse
from pathlib import Path
import numpy as np
from scipy.optimize import minimize


def optimum(d, r, n, sigma2, k):
    alpha = (n + 1 + r * (1 + sigma2)) / n
    beta = (d - r) * (1 + sigma2) / n
    k0 = (r - 1) / (alpha * (r - 1) + beta * r)
    k1 = r / alpha
    if k <= k0:
        a = b = k
    elif k < k1:
        den = alpha * (r - 1) ** 2 + beta * r ** 2
        a = ((r - 1) ** 2 + beta * r * k) / den
        b = (r - 1) * (r - alpha * k) / den
    else:
        a, b = 1 / alpha, 0.0
    return a, b, 1 - 2 * a + alpha * a * a + beta * b * b, k0, k1


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--full-matrix', action='store_true', help='Also run a nonsmooth matrix diagnostic; convergence flags may fail.')
    parser.add_argument('--output', default=None)
    args = parser.parse_args()
    rng = np.random.default_rng(20261031)
    d, r, n, sigma2 = 6, 2, 4, 1.0
    kappas = [0.08, 0.16, 0.4, 0.8, 8 / 9, 1.2]
    answers = [optimum(d, r, n, sigma2, k) for k in kappas]
    ntrials, batch = 200_000, 10_000
    sums = np.zeros(len(kappas))
    sumsq = np.zeros(len(kappas))
    for _ in range(ntrials // batch):
        theta = np.zeros((batch, d))
        theta[:, :r] = rng.normal(size=(batch, r)) / np.sqrt(r)
        x = rng.normal(size=(batch, n, d))
        y = np.einsum('bnd,bd->bn', x, theta) + rng.normal(size=(batch, n)) * np.sqrt(sigma2)
        z = np.einsum('bnd,bn->bd', x, y) / n
        for j, (a, b, _, _, _) in enumerate(answers):
            gains = np.r_[np.repeat(a, r), np.repeat(b, d-r)]
            err = np.sum((z * gains - theta) ** 2, axis=1)
            sums[j] += err.sum()
            sumsq[j] += np.dot(err, err)

    # Optimize in the space of ALL symmetric matrices, with a randomly rotated
    # task subspace.  G >= t I and tr G - (d-1)t <= k represent the gauge budget.
    rotation, _ = np.linalg.qr(rng.normal(size=(d, d)))
    projector = rotation[:, :r] @ rotation[:, :r].T
    source = projector / r
    ii, jj = np.triu_indices(d)
    diagonal_mask = ii == jj
    rho = (1 + sigma2) / n
    c = (n + 1) / n
    def unpack(v):
        g = np.zeros((d, d))
        g[ii, jj] = v[:-1]
        g[jj, ii] = v[:-1]
        return g, v[-1]
    def objective(v):
        g, _ = unpack(v)
        return 1 - 2 * np.trace(g @ source) + c * np.trace(g @ g @ source) + rho * np.trace(g @ g)
    def jacobian(v):
        g, _ = unpack(v)
        grad = -2 * source + c * (g @ source + source @ g) + 2 * rho * g
        triangular = grad[ii, jj].copy()
        triangular[~diagonal_mask] *= 2
        return np.r_[triangular, 0.0]

    rows = []
    for j, (k, (a, b, exact, k0, k1)) in enumerate(zip(kappas, answers)):
        eigen_source = np.r_[np.repeat(1/r, r), np.zeros(d-r)]
        qweights = c * eigen_source + rho
        def diagonal_objective(v):
            g = v[:-1]
            return 1 - 2 * eigen_source @ g + qweights @ (g*g)
        def diagonal_jacobian(v):
            return np.r_[-2*eigen_source + 2*qweights*v[:-1], 0.0]
        constraint_matrix = np.zeros((d+2, d+1))
        constraint_matrix[:d, :d] = np.eye(d)
        constraint_matrix[:d, -1] = -1
        constraint_matrix[d, -1] = 1
        constraint_matrix[d+1, :d] = -1
        constraint_matrix[d+1, -1] = d-1
        constraint_offset = np.r_[np.zeros(d+1), k]
        diagonal = minimize(diagonal_objective, np.repeat(k/2, d+1), method='SLSQP', jac=diagonal_jacobian,
                            constraints={'type':'ineq', 'fun':lambda v: constraint_matrix@v+constraint_offset,
                                         'jac':lambda v: constraint_matrix},
                            options={'ftol':1e-12,'maxiter':500})
        matrix_diagnostic = None
        if args.full_matrix:
            initial = np.r_[(k / 2 * np.eye(d))[ii, jj], k / 2]
            def constraints(v):
                g, t = unpack(v)
                return np.r_[np.linalg.eigvalsh(g - t * np.eye(d)), t, k - np.trace(g) + (d-1)*t]
            result = minimize(objective, initial, method='SLSQP', jac=jacobian,
                              constraints={'type':'ineq','fun':constraints},
                              options={'ftol': 1e-11, 'maxiter': 1200})
            found, _ = unpack(result.x)
            target = a * projector + b * (np.eye(d) - projector)
            matrix_diagnostic = dict(success=bool(result.success), risk=float(result.fun),
                                     frobenius_error=float(np.linalg.norm(found-target, 'fro')),
                                     min_constraint=float(np.min(constraints(result.x))))
        mean = sums[j] / ntrials
        variance = (sumsq[j] - sums[j] ** 2 / ntrials) / (ntrials - 1)
        rows.append(dict(k=k, a=a, b=b, analytic_risk=exact,
                         monte_carlo_risk=mean, monte_carlo_standard_error=np.sqrt(variance/ntrials),
                         diagonal_qp_success=bool(diagonal.success),
                         diagonal_qp_risk=float(diagonal.fun),
                         diagonal_qp_eigenvalue_error=float(np.linalg.norm(diagonal.x[:-1]-np.r_[np.repeat(a,r),np.repeat(b,d-r)])),
                         diagonal_qp_min_constraint=float(np.min(constraint_matrix@diagonal.x+constraint_offset)),
                         full_matrix_diagnostic=matrix_diagnostic))
    output = json.dumps(dict(seed=20261031, d=d, r=r, n=n, sigma2=sigma2,
                             monte_carlo_trials=ntrials, lower_threshold=answers[0][3],
                             upper_threshold=answers[0][4], results=rows), indent=2)
    if args.output:
        Path(args.output).write_text(output+'\n')
    print(output)


if __name__ == '__main__':
    main()
