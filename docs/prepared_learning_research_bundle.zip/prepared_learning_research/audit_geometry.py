"""Independent numerical audit of the zero-function plasticity energy theorem.

Run with Python 3 and NumPy; writes audit_geometry_results.json next to this file.
The computations provide finite numerical checks, not a mathematical proof.
Complex-step parameter derivatives independently check the analytic Jacobian.
"""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np


SEED = 123


def effective_row(weights):
    product = np.eye(weights[0].shape[1], dtype=np.result_type(*weights))
    for weight in weights:
        product = weight @ product
    return product.ravel()


def geometry_and_update_directions(weights, task_direction=None):
    dimension = weights[0].shape[1]
    geometry = np.zeros((dimension, dimension))
    prefix = np.eye(dimension)
    updates = []
    for layer in range(len(weights)):
        suffix = np.ones((1, 1))
        for weight in reversed(weights[layer + 1 :]):
            suffix = suffix @ weight
        geometry += float(np.sum(suffix * suffix)) * (prefix.T @ prefix)
        if task_direction is not None:
            updates.append(suffix.T @ (prefix @ task_direction)[None, :])
        prefix = weights[layer] @ prefix
    return geometry, updates


def complex_step_geometry(weights, step=1e-25):
    columns = []
    for layer, weight in enumerate(weights):
        for index in np.ndindex(weight.shape):
            perturbed = [array.astype(complex) for array in weights]
            perturbed[layer][index] += 1j * step
            columns.append(np.imag(effective_row(perturbed)) / step)
    jacobian = np.stack(columns, axis=1)
    return jacobian @ jacobian.T, jacobian.shape[1]


def random_null_network(rng, depth, dimension):
    # Every internal width is d+2.  The final row is chosen from the left
    # nullspace of the preceding product.  The remaining matrices are random.
    sizes = [dimension] + [dimension + 2] * (depth - 1) + [1]
    weights = [
        rng.normal(size=(sizes[i + 1], sizes[i])) / np.sqrt(sizes[i])
        for i in range(depth)
    ]
    prefix = np.eye(dimension)
    for weight in weights[:-1]:
        prefix = weight @ prefix
    left_singular_vectors, _, _ = np.linalg.svd(prefix, full_matrices=True)
    final_row = left_singular_vectors[:, dimension:] @ rng.normal(size=2)
    weights[-1] = final_row[None, :]
    return weights


def optimal_network(eigenvectors, eigenvalues, depth):
    dimension = len(eigenvalues)
    lam = float(eigenvalues[0])
    gamma = float(sum(eigenvalues) - (dimension - 1) * lam)
    if gamma == 0:
        return [np.zeros((1, dimension))] + [np.zeros((1, 1)) for _ in range(depth - 1)]
    scale = gamma ** (1 / (depth - 1))
    tangent_multiplier = scale ** (depth - 2)
    nonminimum = np.flatnonzero(eigenvalues > lam + 1e-12)
    first = (
        np.sqrt((eigenvalues[nonminimum] - lam) / tangent_multiplier)[:, None]
        * eigenvectors[:, nonminimum].T
    )
    second = np.zeros(len(nonminimum) + int(lam > 0))
    if lam > 0:
        first = np.vstack((first, np.zeros((1, dimension))))
        second[-1] = np.sqrt(lam / tangent_multiplier)
    return [first, second[None, :]] + [
        np.array([[np.sqrt(scale)]]) for _ in range(depth - 2)
    ]


def main():
    rng = np.random.default_rng(SEED)
    random_count = 0
    maximum_lower_bound_ratio = 0.0
    maximum_random_null_residual = 0.0
    complex_count = 0
    complex_parameter_count = 0
    maximum_complex_geometry_error = 0.0
    for depth in range(2, 9):
        for dimension in range(1, 7):
            for repetition in range(300):
                weights = random_null_network(rng, depth, dimension)
                geometry, _ = geometry_and_update_directions(weights)
                energy = sum(float(np.sum(weight * weight)) for weight in weights)
                gamma = float(
                    np.trace(geometry)
                    - (dimension - 1) * np.linalg.eigvalsh(geometry)[0]
                )
                lower_bound = (depth - 1) * max(0.0, gamma) ** (1 / (depth - 1))
                maximum_lower_bound_ratio = max(maximum_lower_bound_ratio, lower_bound / energy)
                maximum_random_null_residual = max(
                    maximum_random_null_residual,
                    float(np.max(np.abs(effective_row(weights)))),
                )
                assert lower_bound <= energy * (1 + 1e-10)
                random_count += 1
                if repetition == 0:
                    independent_geometry, parameters = complex_step_geometry(weights)
                    maximum_complex_geometry_error = max(
                        maximum_complex_geometry_error,
                        float(np.max(np.abs(independent_geometry - geometry))),
                    )
                    complex_count += 1
                    complex_parameter_count += parameters

    optimal_count = 0
    maximum_energy_error = 0.0
    maximum_geometry_error = 0.0
    maximum_optimal_null_residual = 0.0
    maximum_one_step_error = 0.0
    maximum_width_error = 0
    spectrum_types = ("positive", "singular", "repeated_minimum", "isotropic", "zero")
    for depth in range(2, 9):
        for dimension in range(1, 7):
            for spectrum_type in spectrum_types:
                for repetition in range(10):
                    orthogonal, _ = np.linalg.qr(rng.normal(size=(dimension, dimension)))
                    spectrum = np.sort(rng.uniform(0.1, 2.0, size=dimension))
                    if spectrum_type == "singular":
                        spectrum[: max(1, dimension // 2)] = 0.0
                    elif spectrum_type == "repeated_minimum":
                        spectrum[: max(1, dimension // 2)] = spectrum[0]
                    elif spectrum_type == "isotropic":
                        spectrum[:] = spectrum[0]
                    elif spectrum_type == "zero":
                        spectrum[:] = 0.0
                    target_geometry = orthogonal @ np.diag(spectrum) @ orthogonal.T
                    lam = float(spectrum[0])
                    gamma = float(sum(spectrum) - (dimension - 1) * lam)
                    weights = optimal_network(orthogonal, spectrum, depth)
                    energy = sum(float(np.sum(weight * weight)) for weight in weights)
                    target_energy = (depth - 1) * gamma ** (1 / (depth - 1))
                    direction = rng.normal(size=dimension)
                    geometry, updates = geometry_and_update_directions(weights, direction)
                    step_size = rng.uniform(0.01, 2.0)
                    after = [weight + step_size * update for weight, update in zip(weights, updates)]
                    maximum_energy_error = max(maximum_energy_error, abs(energy - target_energy))
                    maximum_geometry_error = max(
                        maximum_geometry_error, float(np.max(np.abs(geometry - target_geometry)))
                    )
                    maximum_optimal_null_residual = max(
                        maximum_optimal_null_residual, float(np.max(np.abs(effective_row(weights))))
                    )
                    maximum_one_step_error = max(
                        maximum_one_step_error,
                        float(np.max(np.abs(effective_row(after) - step_size * target_geometry @ direction))),
                    )
                    expected_width = max(
                        1, int(np.count_nonzero(spectrum > lam + 1e-12)) + int(lam > 0)
                    )
                    maximum_width_error = max(maximum_width_error, abs(weights[0].shape[0] - expected_width))
                    optimal_count += 1

    result = {
        "seed": SEED,
        "numpy_version": np.__version__,
        "depths": [2, 3, 4, 5, 6, 7, 8],
        "input_dimensions": [1, 2, 3, 4, 5, 6],
        "random_null_networks": random_count,
        "maximum_claimed_lower_bound_divided_by_energy": maximum_lower_bound_ratio,
        "maximum_random_null_function_residual": maximum_random_null_residual,
        "complex_step_jacobian_networks": complex_count,
        "complex_step_parameter_derivatives": complex_parameter_count,
        "maximum_complex_step_geometry_absolute_error": maximum_complex_geometry_error,
        "optimal_construction_networks": optimal_count,
        "optimal_construction_spectrum_types": spectrum_types,
        "maximum_optimal_energy_absolute_error": maximum_energy_error,
        "maximum_optimal_geometry_absolute_error": maximum_geometry_error,
        "maximum_optimal_null_function_residual": maximum_optimal_null_residual,
        "maximum_exact_one_step_absolute_error": maximum_one_step_error,
        "maximum_first_width_error": maximum_width_error,
        "status": "all numerical assertions passed; finite checks do not establish the theorem",
    }
    assert maximum_energy_error < 1e-10
    assert maximum_geometry_error < 1e-10
    assert maximum_one_step_error < 1e-9
    assert maximum_width_error == 0
    output_path = Path(__file__).with_name("audit_geometry_results.json")
    output_path.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
