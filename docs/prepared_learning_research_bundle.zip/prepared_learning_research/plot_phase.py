"""Plot the proved phase diagram; these curves are analytic, not fitted."""
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

HERE = Path(__file__).resolve().parent
OUT = HERE / 'figures'
OUT.mkdir(exist_ok=True)
d, r, n, sigma2 = 6, 2, 4, 1.0
alpha = (n + 1 + r * (1 + sigma2)) / n
beta = (d - r) * (1 + sigma2) / n
D = alpha * (r - 1)**2 + beta * r**2
k0 = (r - 1) / (alpha * (r - 1) + beta * r)
k1 = r / alpha
k = np.unique(np.r_[np.linspace(0, 1.15, 900), k0, k1])
a = np.where(k <= k0, k, np.where(k < k1,
    ((r - 1)**2 + beta*r*k) / D, 1/alpha))
b = np.where(k <= k0, k, np.where(k < k1,
    (r-1)*(r-alpha*k) / D, 0))
risk = 1 - 2*a + alpha*a*a + beta*b*b
special_a = np.minimum(k/r, 1/alpha)
special_risk = 1 - 2*special_a + alpha*special_a**2
iso_a = np.minimum(k, 1/(alpha+beta))
iso_risk = 1 - 2*iso_a + (alpha+beta)*iso_a**2

plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 11,
    'axes.spines.top': False, 'axes.spines.right': False,
    'axes.labelcolor': '#223246', 'text.color': '#223246',
    'xtick.color': '#526174', 'ytick.color': '#526174'})
fig, axes = plt.subplots(1, 3, figsize=(14, 4.3),
    gridspec_kw={'width_ratios': [1.1, 1.25, 0.8]})
colors = ['#edf4fb', '#f4f0fc', '#edf6f1']
for ax in axes:
    for lo, hi, color in zip([0,k0,k1], [k0,k1,1.15], colors):
        ax.axvspan(lo, hi, color=color, zorder=0)
    for boundary in [k0,k1]:
        ax.axvline(boundary, color='#a7aebb', lw=0.9, ls=':')
    ax.set_xlim(0, 1.15)
    ax.set_xlabel(r'Effective norm budget $k$')
    ax.grid(axis='y', color='white', linewidth=1)
    ax.set_axisbelow(True)
axes[0].plot(k, a, color='#185aa6', lw=2.5, label='Task directions: a')
axes[0].plot(k, b, color='#b25b22', lw=2.5, label='Other directions: b')
axes[0].set_ylabel('Eigenvalue of learning matrix')
axes[0].set_title('Learning geometry', loc='left', weight='bold')
axes[0].legend(loc='upper left', frameon=False, fontsize=9)
axes[1].plot(k, risk, color='#185aa6', lw=2.5, label='Optimal')
axes[1].plot(k, special_risk, color='#b25b22', lw=1.7, ls='--', label='Forced specialization')
axes[1].plot(k, iso_risk, color='#75559f', lw=1.7, ls='-.', label='Forced isotropy')
axes[1].set_ylabel('Expected squared coefficient error')
axes[1].set_title('Risk under the same budget', loc='left', weight='bold')
axes[1].legend(loc='upper right', frameon=False, fontsize=9)
axes[2].plot([0,k0], [1,1], color='#185aa6', lw=2.5)
axes[2].plot([k0,k1], [r+1,r+1], color='#185aa6', lw=2.5)
axes[2].plot([k1,1.15], [r,r], color='#185aa6', lw=2.5)
axes[2].scatter([k0,k1], [1,r], color='#185aa6', s=35, zorder=5)
axes[2].scatter([k0,k1], [r+1,r+1], facecolor='white', edgecolor='#185aa6', s=35, zorder=5)
axes[2].set_ylim(0.65,3.5)
axes[2].set_yticks([1,2,3])
axes[2].set_ylabel('Minimum first hidden width')
axes[2].set_title('Width rises, then falls', loc='left', weight='bold')
fig.suptitle('A norm budget creates three adaptation regimes', x=0.06, ha='left',
             fontsize=17, weight='bold', y=1.01)
fig.text(0.06, -0.02,
    r'Analytic model: $d=6$, $r=2$, $n=4$, $\sigma^2=1$. '
    r'Transitions at $k_0=0.16$ and $k_1=8/9$. '
    r'For depth $L$, $k=(B/(L-1))^{L-1}$.', fontsize=10)
fig.tight_layout()
fig.savefig(OUT/'phase_diagram.png', dpi=180, bbox_inches='tight', facecolor='white')
fig.savefig(OUT/'phase_diagram.pdf', bbox_inches='tight', facecolor='white')
# A separate portrait layout keeps labels readable in a single-column note.
fig.set_size_inches(7, 8.2)
for ax, bottom in zip(axes, [0.70, 0.40, 0.10]):
    ax.set_position([0.15, bottom, 0.81, 0.23])
axes[0].set_xlabel('')
axes[1].set_xlabel('')
axes[0].set_ylabel('Learning eigenvalue')
axes[1].set_ylabel('Expected squared error')
axes[2].set_ylabel('First hidden width')
fig._suptitle.set_position((0.15, 0.99))
fig._suptitle.set_fontsize(14)
for item in fig.texts:
    if item is not fig._suptitle:
        item.set_visible(False)
fig.savefig(OUT/'phase_diagram_note.pdf', bbox_inches='tight', facecolor='white')
print(OUT/'phase_diagram.png')
