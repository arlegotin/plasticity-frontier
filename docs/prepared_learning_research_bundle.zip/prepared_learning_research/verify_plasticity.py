"""Numerical falsification checks for the null-network kernel cost theorem.

Requires NumPy. Run from any directory; optional --output PATH writes JSON.
The theorem is proved analytically; finite checks here are not its proof.
All random seeds are fixed. Zero target kernels are handled explicitly.
"""

import argparse
import json
from pathlib import Path

import numpy as np


def tangent_kernel(layers):
    """Return the input-space NTK matrix and complete product."""
    dimension = layers[0].shape[1]
    metric = np.zeros((dimension, dimension))
    prefix = np.eye(dimension)
    for index, layer in enumerate(layers):
        suffix = np.ones((1, 1))
        for later_layer in reversed(layers[index + 1 :]):
            suffix = suffix @ later_layer
        metric += np.sum(suffix * suffix) * (prefix.T @ prefix)
        prefix = layer @ prefix
    return metric, prefix


def null_network_bound_checks():
    rng = np.random.default_rng(4813)
    maximum_ratio = 0.0
    maximum_relative_null_error = 0.0
    count = 0
    ratios_by_depth = {}
    for depth in range(2, 9):
        depth_max = 0.0
        for dimension in range(1, 9):
            for _ in range(100):
                widths = (
                    [dimension]
                    + [int(rng.integers(dimension + 1, dimension + 5))
                       for _ in range(depth - 1)]
                    + [1]
                )
                layers = [rng.normal(size=(widths[j + 1], widths[j]))
                          for j in range(depth)]
                cut = int(rng.integers(0, depth))
                # Force a null product by projecting this layer off its
                # backward vector. Subsequent layers are left unchanged.
                if cut == depth - 1:
                    layers[cut] *= 0
                else:
                    suffix = np.ones((1, 1))
                    for layer in reversed(layers[cut + 1 :]):
                        suffix = suffix @ layer
                    backward = suffix.ravel()
                    layers[cut] -= np.outer(
                        backward, backward @ layers[cut]
                    ) / (backward @ backward)
                metric, product = tangent_kernel(layers)
                energy = sum(float(np.sum(layer * layer)) for layer in layers)
                eigenvalues = np.linalg.eigvalsh(metric)
                gamma = float(eigenvalues.sum()
                              - (dimension - 1) * eigenvalues[0])
                ratio = gamma / (energy / (depth - 1)) ** (depth - 1)
                norm_scale = float(np.prod([np.linalg.norm(layer)
                                           for layer in layers]))
                relative_error = float(np.linalg.norm(product)
                                       / max(norm_scale, 1.0))
                assert np.isfinite(ratio)
                assert ratio <= 1.0 + 1e-10
                assert relative_error < 1e-12
                maximum_ratio = max(maximum_ratio, ratio)
                depth_max = max(depth_max, ratio)
                maximum_relative_null_error = max(
                    maximum_relative_null_error, relative_error
                )
                count += 1
        ratios_by_depth[str(depth)] = depth_max
    return {
        "seed": 4813,
        "depths": [2, 8],
        "input_dimensions": [1, 8],
        "networks_tested": count,
        "max_gamma_to_budget_ratio": maximum_ratio,
        "max_relative_null_error": maximum_relative_null_error,
        "max_ratio_by_depth": ratios_by_depth,
    }


def optimal_construction_checks():
    rng = np.random.default_rng(4813)
    maxima = {key: 0.0 for key in ["kernel", "energy", "null", "one_step"]}
    count = 0
    zero_cases = 0
    for depth in range(2, 9):
        for dimension in range(1, 9):
            for index in range(25):
                eigenvalues = rng.uniform(0.1, 3.0, size=dimension)
                if index % 2:
                    eigenvalues[0] = 0
                rotation, _ = np.linalg.qr(
                    rng.normal(size=(dimension, dimension))
                )
                metric = (rotation * eigenvalues) @ rotation.T
                minimum = float(eigenvalues.min())
                gamma = float(eigenvalues.sum() - (dimension - 1) * minimum)
                if gamma == 0:
                    layers = [np.zeros((dimension, dimension)),
                              np.zeros((1, dimension))]
                    layers += [np.zeros((1, 1)) for _ in range(depth - 2)]
                    balanced_energy = 0.0
                    scalar_product = 0.0 if depth > 2 else 1.0
                    zero_cases += 1
                else:
                    balanced_energy = gamma ** (1.0 / (depth - 1))
                    multiplier = balanced_energy ** (depth - 2)
                    scalar_product = np.sqrt(multiplier)
                    minimum_index = int(np.argmin(eigenvalues))
                    first = np.diag(np.sqrt(
                        np.maximum(eigenvalues - minimum, 0.0) / multiplier
                    )) @ rotation.T
                    second = np.zeros((1, dimension))
                    second[0, minimum_index] = np.sqrt(minimum / multiplier)
                    layers = [first, second]
                    layers += [np.array([[np.sqrt(balanced_energy)]])
                               for _ in range(depth - 2)]
                observed, product = tangent_kernel(layers)
                energy = sum(float(np.sum(layer * layer)) for layer in layers)
                first, second = layers[:2]
                gradient = rng.normal(size=dimension)
                learning_rate = 0.3
                second_new = second - learning_rate * scalar_product * (
                    first @ gradient
                )[None, :]
                first_new = first - learning_rate * scalar_product * (
                    second.T @ gradient[None, :]
                )
                predictor_new = scalar_product * (second_new @ first_new).ravel()
                errors = {
                    "kernel": float(np.linalg.norm(observed - metric)),
                    "energy": abs(energy - (depth - 1) * balanced_energy),
                    "null": float(np.linalg.norm(product)),
                    "one_step": float(np.linalg.norm(
                        predictor_new + learning_rate * metric @ gradient
                    )),
                }
                assert all(np.isfinite(value) for value in errors.values())
                assert max(errors.values()) < 1e-10
                for key, value in errors.items():
                    maxima[key] = max(maxima[key], value)
                count += 1
    return {
        "seed": 4813,
        "depths": [2, 8],
        "input_dimensions": [1, 8],
        "networks_tested": count,
        "zero_kernel_cases": zero_cases,
        "maximum_absolute_errors": maxima,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    results = {
        "random_null_networks": null_network_bound_checks(),
        "optimal_constructions": optimal_construction_checks(),
        "interpretation": "Numerical checks support but do not prove the theorem.",
    }
    serialized = json.dumps(results, indent=2)
    if args.output is not None:
        args.output.write_text(serialized + "\n")
    print(serialized)


if __name__ == "__main__":
    main()
